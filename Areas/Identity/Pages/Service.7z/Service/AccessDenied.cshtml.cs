﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Mvc_IdentityServer.Areas.Identity.Pages.Service
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}

